﻿DROP TABLE IF EXISTS Gerente CASCADE;
DROP TABLE IF EXISTS Vendedor CASCADE;
DROP TABLE IF EXISTS Jefe_Taller CASCADE;
DROP TABLE IF EXISTS Inventario CASCADE;
DROP TABLE IF EXISTS Cotizacion CASCADE;
DROP TABLE IF EXISTS Venta CASCADE;
DROP TABLE IF EXISTS Orden_Trabajo CASCADE;
DROP TABLE IF EXISTS Sede CASCADE;


--
-- TABLE: Gerente
-- 
--  

CREATE TABLE SuperUsuario (
  id_SuperUsuario VARCHAR(100) NOT NULL,
  contrasenia VARCHAR(100) NOT NULL,

  PRIMARY KEY (id_SuperUsuario)
);

--
-- TABLE: Gerente
-- 
--  

CREATE TABLE Gerente (
  id_Gerente VARCHAR(100) NOT NULL,
  nombre_Gerente VARCHAR(100) NOT NULL ,
  cedula VARCHAR(100) NOT NULL,
  cargo VARCHAR(100) NOT NULL ,
  e_mail VARCHAR(100) NOT NULL ,
  genero int NOT NULL ,
  direccion VARCHAR(100) NOT NULL ,
  telefono VARCHAR(100) NOT NULL ,
  salario double NOT NULL ,
  fecha_Nacimiento VARCHAR(100) NOT NULL ,
  cuenta_Bancaria VARCHAR(100) NOT NULL ,
  fecha_Registro VARCHAR(100) NOT NULL,
  nombre_Usuario VARCHAR(100) NOT NULL,
  contrasenia VARCHAR(100) NOT NULL,  
  habilitado boolean NOT NULL,


  PRIMARY KEY (id_Gerente)

);



--
-- TABLE: Vendedor
-- 
--  

CREATE TABLE Vendedor (
  id_Vendedor  VARCHAR(100) NOT NULL,
  contrasenia VARCHAR(100) NOT NULL,
  nombre_Usuario VARCHAR(100) NOT NULL,
  nombre_Vendedor VARCHAR(100) NOT NULL ,
  cedula VARCHAR(100) NOT NULL,
  cargo VARCHAR(100) NOT NULL ,
  telefono VARCHAR(100) NOT NULL ,
  direccion VARCHAR(100) NOT NULL ,
  genero int NOT NULL ,
  fecha_Nacimiento VARCHAR(100) NOT NULL ,
  e_mail VARCHAR(100) NOT NULL ,
  salario double NOT NULL ,
  cuenta_Bancaria VARCHAR(100) NOT NULL ,
  fecha_Registro VARCHAR(100) NOT NULL,
  habilitado boolean NOT NULL,
  id_Gerente VARCHAR(100) NOT NULL, 

  PRIMARY KEY (id_Vendedor),
  FOREIGN KEY (id_Gerente) REFERENCES Gerente(id_Gerente)
);


--
-- TABLE: Jefe_Taller
-- 
--  

CREATE TABLE Jefe_Taller (
  id_Jefe  VARCHAR(100) NOT NULL,
  contrasenia VARCHAR(100) NOT NULL,
  nombre_Usuario VARCHAR(100) NOT NULL,
  nombre_Jefe VARCHAR(100) NOT NULL ,
  cedula  VARCHAR(100) NOT NULL,
  cargo VARCHAR(100) NOT NULL ,
  telefono VARCHAR(100) NOT NULL ,
  direccion VARCHAR(100) NOT NULL ,
  genero VARCHAR(100) NOT NULL ,
  fecha_Nacimiento VARCHAR(100) NOT NULL ,
  e_mail VARCHAR(100) NOT NULL ,
  salario double NOT NULL ,
  cuenta_Bancario VARCHAR(100) NOT NULL ,
  fecha_Registro VARCHAR(100) NOT NULL,
  id_Gerente int NOT NULL,  

  PRIMARY KEY (id_Jefe),
  FOREIGN KEY (id_Gerente) REFERENCES Gerente(id_Gerente)
);


--
-- TABLE: Sede
-- 
--  

CREATE TABLE Sede (
  id_Sede VARCHAR(100) NOT NULL,
  nombre_Sede VARCHAR(100) NOT NULL ,
  direccion VARCHAR(100) NOT NULL ,
  fecha_Creacion VARCHAR(100) NOT NULL ,
  fecha_Finalizacion VARCHAR(100) NOT NULL,
  id_Gerente VARCHAR(100) NOT NULL,

  PRIMARY KEY (id_Sede),
  FOREIGN KEY (id_Gerente) REFERENCES Gerente(id_Gerente)
);


--
-- TABLE: Inventario
-- 
--  

CREATE TABLE Inventario (
  id_Producto VARCHAR(100) NOT NULL,
  nombre_Producto VARCHAR(100) NOT NULL ,
  valor_Unitario double NOT NULL ,
  descripcion_Producto VARCHAR(100) NOT NULL ,
  lote int NOT NULL ,
  catidad_Lote int NOT NULL,
  id_Jefe VARCHAR(100) NOT NULL, 

  PRIMARY KEY (id_Producto),
  FOREIGN KEY (id_Jefe) REFERENCES Jefe_Taller(id_Jefe)
);


--
-- TABLE: Venta
-- 
--  

CREATE TABLE Venta (
  id_Factura VARCHAR(100) NOT NULL,
  nombre_Cliente VARCHAR(100) NOT NULL ,
  telefono_Cliente VARCHAR(100) NOT NULL ,
  cedula_Cliente int NOT NULL ,
  valor_Venta double NOT NULL ,
  descripcion_Venta VARCHAR(100) NOT NULL,
  id_Vendedor VARCHAR(100) NOT NULL,

  PRIMARY KEY (id_Factura),
  FOREIGN KEY (id_Vendedor) REFERENCES Vendedor(id_Vendedor) 
);



--
-- TABLE: Orden_Trabajo
-- 
--  

CREATE TABLE Orden_Trabajo (
  id_Orden VARCHAR(100) NOT NULL,
  nombre_Cliente VARCHAR(100) NOT NULL ,
  id_Cliente VARCHAR(100) NOT NULL,
  telefono_Cliente VARCHAR(100) NOT NULL ,
  valor_Orden double NOT NULL ,
  es_Cliente int NOT NULL,
  descripcion_Orden VARCHAR(100) NOT NULL ,
  estado_Orden VARCHAR(100) NOT NULL ,
  fecha_Entrega VARCHAR(100) NOT NULL,
  id_Jefe VARCHAR(100) NOT NULL,

  PRIMARY KEY (id_Orden),
  FOREIGN KEY (id_Jefe) REFERENCES Jefe_Taller(id_Jefe) 
);


--
-- TABLE: Cotizacion
-- 
--  

CREATE TABLE Cotizacion (
  id_Cotizacion VARCHAR(100) NOT NULL,
  nombre_Producto VARCHAR(100) NOT NULL ,
  valor_Unitario double NOT NULL ,
  cantidad int NOT NULL ,
  descripcion_Producto VARCHAR(100) NOT NULL ,
  nombre_Empresa VARCHAR(100) NOT NULL ,
  telefono_Empresa VARCHAR(100) NOT NULL ,
  direccion_Empresa VARCHAR(100) NOT NULL,
  id_Vendedor VARCHAR(100) NOT NULL,

  PRIMARY KEY (id_Cotizacion),
  FOREIGN KEY (id_Vendedor) REFERENCES Vendedor(id_Vendedor) 
);




