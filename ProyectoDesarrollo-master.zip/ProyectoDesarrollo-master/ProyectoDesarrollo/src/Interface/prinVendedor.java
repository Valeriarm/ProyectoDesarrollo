/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interface;

import Controller.DBConnection;
import Model.Cotizacion;
import Model.OrdenTrabajo;
import Model.Inventario;
import Model.Venta;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import static java.lang.Integer.parseInt;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.Timer;

/**
 *
 * @author Marthox
 * 
 */
public class prinVendedor extends javax.swing.JFrame {
    
    //la variable botonAceptar indica el uso que se le da al botón de la izquierda para cada boton principal
    //1:Agregar, 2:Modificar, 3:Consultar, 4:Anular 0 Eliminar, 0:nada
    private int botonAceptar = 0;  
    private DBConnection bD;
    private String idJefe;
    private String[] listaIds;
    
    public prinVendedor() {
        //DBConnection baseDatos, String idJefe
        initComponents();
        //bD = baseDatos;
        //idJefe = idJefe;
        
        //Fecha
        Date fechaSist = new Date(); 
        SimpleDateFormat formato = new SimpleDateFormat("dd-MMM-yyyy");
        fecha.setText(formato.format(fechaSist));
        
        //Hora
        Timer tiempo = new Timer(100, new prinVendedor.hora());
        tiempo.start();
        

        bAceptar.setVisible(false);
        
        //Elementos del popup menú para modf,agregar y consultar
        cotizacion.setSelected(false);
        venta.setSelected(true);
       }

    class hora implements ActionListener{
    
        public void actionPerformed(ActionEvent e){
        
        Date fechaHora = new Date();
        String pmAm = "hh:mm:ss a";
        SimpleDateFormat format = new SimpleDateFormat(pmAm);
        Calendar hoy = Calendar.getInstance();
        hora.setText(String.format(format.format(fechaHora), hoy));
      
        }
    }
    //private prinVendedor() {
      //  throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    //}
    
    
    private boolean validarCamposVenta(String nombreCliente, String telefono, String cedulaCliente, String vlrVenta, String descripcion){
    
        boolean validacion = true;
        String mensaje = "";
        
        if(telefono.equals("")){mensaje = mensaje+"-Telefono del cliente\n"; validacion = false;}
        if(nombreCliente.equals("")){
            mensaje = mensaje+"- Nombre del cliente\n"; validacion = false;
        }else{
            if(nombreCliente.charAt(0) == ' ') validacion = false;
        } 
        
        if(cedulaCliente.equals("")){mensaje = mensaje+"-Cedula cliente\n"; validacion = false;}
        if(vlrVenta.equals("")){mensaje = mensaje+"-Valor de venta\n"; validacion = false;}
        if(descripcion.equals("")){mensaje = mensaje+"-Descripción del producto\n"; validacion = false;}
    
        System.out.println(mensaje);
        
        if(!validacion){ //Hay campos vacios            
            mensaje = "Los siguientes campos están vacios:\n"+mensaje;
            if((!nombreCliente.equals("")) && (nombreCliente.charAt(0) == ' ')) mensaje = "Nombre de cliente Invalido\n"+mensaje;
            
        }
        
        if(!mensaje.equals("")) JOptionPane.showMessageDialog(this, mensaje);
        
        return validacion;
    }
   
    
    private boolean validarCamposCotizacion(String nombreProducto, String vlrUnitario, String cantidad,String nombreEmpresa, String telefonoEmpresa, String direccionEmpresa){
        
        boolean validacion = true;
        String mensaje = "";
        
        if(nombreProducto.equals("")){
            mensaje = mensaje+"- Nombre de producto\n"; validacion = false;
        }else{
            if(nombreProducto.charAt(0) == ' ') validacion = false;
        } 
        
        if(vlrUnitario.equals("")){mensaje = mensaje+"-Valor por unidad\n"; validacion = false;}
        if(cantidad.equals("")){mensaje = mensaje+"-Cantidad\n"; validacion = false;}
        if(nombreEmpresa.equals("")){mensaje = mensaje+"-Nombre de la empresa cotizante\n"; validacion = false;}
        if(telefonoEmpresa.equals("")){mensaje = mensaje+"-Telefonos de la empresa cotizante\n"; validacion = false;}
        if(direccionEmpresa.equals("")){mensaje = mensaje+"-Direccion de la empresa cotizante\n"; validacion = false;}
        
        System.out.println(mensaje);
        
        if(!validacion){ //Hay campos vacios            
            mensaje = "Los siguientes campos están vacios:\n"+mensaje;
            if((!nombreProducto.equals("")) && (nombreProducto.charAt(0) == ' ')) mensaje = "Nombre de producto Invalido\n"+mensaje;
            
        }
        
        if(!mensaje.equals("")) JOptionPane.showMessageDialog(this, mensaje);
        
        
        return validacion;
    }
    
     //Retorna una lista con los Ids de las ventas en listaVentas la cual es una lista de strings,
    //donde N es la cantiadad de ventas
    private String[] obtenerListaIdsVentas(String[] listaVentas){
        String[] listaDeIds = new String[listaVentas.length];
        String[] venta;
        
        for(int i=0; i<(listaDeIds.length); i++){
            venta = listaVentas[i].split(",");
            listaDeIds[i] = venta[0];
        }
        
        return listaDeIds;
    }
    

    //Retorna una lista con los Ids de las cotizaciones en listaCotizacion el cual es una lista de strings,
    //donde N es la cantiadad de cotizacion
    private String[] obtenerListaIdsCotizacion(String[] listaCotizacion){
        String[] listaDeIds = new String[listaCotizacion.length];
        String[] cotizacion;
        
        for(int i=0; i<(listaDeIds.length); i++){
            cotizacion = listaCotizacion[i].split(",");
            listaDeIds[i] = cotizacion[0];
        }
        
        return listaDeIds;
    }
    
    //Retorna una lista con las opciones para combobox comboxEmple con el formato
    //{"nombre1 cedula1",..."nombreN cedulaN"} obtenidas de listaEmpleado el cual es una lista de strings del
    //tipo {"id1,nombre1,cedula1",..."idN,nombreN,cedulaN"} donde N es la cantiadad de empleados
    private String[] obtenerOpcionesVentas(String[] listaVentas){
        String[] opcionesVentas = new String[listaVentas.length+1];
        String[] venta;
        opcionesVentas[0] = "No seleccionado";
        
        for(int i=0,j=1; i<(listaVentas.length); i++,j++){
            venta = listaVentas[i].split(",");
            opcionesVentas[j] = venta[1]+" "+venta[2].replace("$","");
        }
        
        return opcionesVentas;
    }
    
    private String[] obtenerOpcionesCotizacion(String[] listaCotizacion){
        String[] opcionesCotizacion = new String[listaCotizacion.length+1];
        String[] cotizacion;
        opcionesCotizacion[0] = "No seleccionado";
        
        for(int i=0,j=1; i<(listaCotizacion.length); i++,j++){
            cotizacion = listaCotizacion[i].split(",");
            opcionesCotizacion[j] = cotizacion[1]+" "+cotizacion[2].replace("$","");
        }
        
        return opcionesCotizacion;
    }
 /*   
    private void actualizarComboxCot(){
    
            String cotizaciones = bD.listarCotizaciones();
        
        if(cotizaciones.equals("")){ //No Hay empleados
           String[] opciones = { "No seleccionado" };
    }
    
*/
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        vendedor = new javax.swing.JPopupMenu();
        cotizacion = new javax.swing.JCheckBoxMenuItem();
        venta = new javax.swing.JCheckBoxMenuItem();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        iconUsu = new javax.swing.JLabel();
        labLogo = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        fecha = new javax.swing.JLabel();
        fechaYhora = new javax.swing.JLabel();
        hora = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        bAgregar = new javax.swing.JButton();
        bModf = new javax.swing.JButton();
        bConsul = new javax.swing.JButton();
        bAnular = new javax.swing.JButton();
        bReportes = new javax.swing.JToggleButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        bAgregarCot = new javax.swing.JButton();
        bAgregarCot1 = new javax.swing.JButton();
        bAgregarCot2 = new javax.swing.JButton();
        bAgregarCot3 = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        bAceptar = new javax.swing.JButton();
        labIDcotizacion = new javax.swing.JLabel();
        comboxCotizacion = new javax.swing.JComboBox<>();
        labNombrePro = new javax.swing.JLabel();
        tNombrePro = new javax.swing.JTextField();
        tVlrUnd = new javax.swing.JTextField();
        labVlrUnd = new javax.swing.JLabel();
        labCantidad = new javax.swing.JLabel();
        tCantidad = new javax.swing.JTextField();
        tEmpresaCo = new javax.swing.JTextField();
        labEmpresaCo = new javax.swing.JLabel();
        labNombreCliente = new javax.swing.JLabel();
        tNombreCliente = new javax.swing.JTextField();
        tIDfactura = new javax.swing.JTextField();
        labIDfactura = new javax.swing.JLabel();
        labPrecio = new javax.swing.JLabel();
        tPrecio = new javax.swing.JTextField();
        tCCcliente = new javax.swing.JTextField();
        labCCcliente = new javax.swing.JLabel();
        labDir = new javax.swing.JLabel();
        tDir = new javax.swing.JTextField();
        tTel = new javax.swing.JTextField();
        labTel = new javax.swing.JLabel();
        labDescrip = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tDescrip = new javax.swing.JTextArea();

        cotizacion.setSelected(true);
        cotizacion.setText("Cotización");
        cotizacion.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                cotizacionMouseReleased(evt);
            }
        });
        vendedor.add(cotizacion);

        venta.setSelected(true);
        venta.setText("Venta");
        venta.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                ventaMouseReleased(evt);
            }
        });
        vendedor.add(venta);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(51, 51, 51));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        iconUsu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/user (1).png"))); // NOI18N

        labLogo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/28315579-72de-482c-8e2f-b89ce3cb00d1 (4).png"))); // NOI18N
        labLogo.setName(""); // NOI18N

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));

        fecha.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        fecha.setText("dd-mm-yyyy");

        fechaYhora.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        fechaYhora.setText("Fecha  y hora:");

        hora.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        hora.setText("hh:mm:ss");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 263, Short.MAX_VALUE)
            .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel5Layout.createSequentialGroup()
                    .addGap(78, 78, 78)
                    .addComponent(fecha)
                    .addContainerGap(125, Short.MAX_VALUE)))
            .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel5Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(fechaYhora)
                    .addContainerGap(186, Short.MAX_VALUE)))
            .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel5Layout.createSequentialGroup()
                    .addGap(142, 142, 142)
                    .addComponent(hora)
                    .addContainerGap(77, Short.MAX_VALUE)))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 28, Short.MAX_VALUE)
            .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                    .addGap(1, 1, 1)
                    .addComponent(fecha, javax.swing.GroupLayout.DEFAULT_SIZE, 16, Short.MAX_VALUE)
                    .addContainerGap()))
            .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel5Layout.createSequentialGroup()
                    .addGap(3, 3, 3)
                    .addComponent(fechaYhora)
                    .addContainerGap(7, Short.MAX_VALUE)))
            .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel5Layout.createSequentialGroup()
                    .addGap(4, 4, 4)
                    .addComponent(hora)
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(labLogo)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(iconUsu)
                        .addGap(61, 61, 61))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(labLogo, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                        .addGap(37, 37, 37)
                        .addComponent(iconUsu)
                        .addGap(20, 20, 20)
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        bAgregar.setForeground(new java.awt.Color(51, 51, 51));
        bAgregar.setText("Venta");
        bAgregar.setBorderPainted(false);
        bAgregar.setContentAreaFilled(false);
        bAgregar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                bAgregarMouseReleased(evt);
            }
        });

        bModf.setForeground(new java.awt.Color(51, 51, 51));
        bModf.setText("Venta");
        bModf.setBorderPainted(false);
        bModf.setContentAreaFilled(false);
        bModf.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                bModfMouseReleased(evt);
            }
        });
        bModf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bModfActionPerformed(evt);
            }
        });

        bConsul.setForeground(new java.awt.Color(51, 51, 51));
        bConsul.setText("venta");
        bConsul.setBorderPainted(false);
        bConsul.setContentAreaFilled(false);
        bConsul.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                bConsulMouseReleased(evt);
            }
        });
        bConsul.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bConsulActionPerformed(evt);
            }
        });

        bAnular.setForeground(new java.awt.Color(51, 51, 51));
        bAnular.setText("venta");
        bAnular.setBorderPainted(false);
        bAnular.setContentAreaFilled(false);
        bAnular.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                bAnularMouseReleased(evt);
            }
        });

        bReportes.setForeground(new java.awt.Color(51, 51, 51));
        bReportes.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/growth.png"))); // NOI18N
        bReportes.setText("Reportes");
        bReportes.setBorderPainted(false);
        bReportes.setContentAreaFilled(false);
        bReportes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bReportesActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel1.setText("---------- Agregar ----------");

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel2.setText("---------- Modificar ----------");

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel3.setText("---------- Consultar ----------");

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel4.setText("---------- Anular ----------");

        bAgregarCot.setForeground(new java.awt.Color(51, 51, 51));
        bAgregarCot.setText("cotizacion");
        bAgregarCot.setBorderPainted(false);
        bAgregarCot.setContentAreaFilled(false);
        bAgregarCot.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                bAgregarCotMouseReleased(evt);
            }
        });

        bAgregarCot1.setForeground(new java.awt.Color(51, 51, 51));
        bAgregarCot1.setText("cotizacion");
        bAgregarCot1.setBorderPainted(false);
        bAgregarCot1.setContentAreaFilled(false);
        bAgregarCot1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                bAgregarCot1MouseReleased(evt);
            }
        });

        bAgregarCot2.setForeground(new java.awt.Color(51, 51, 51));
        bAgregarCot2.setText("cotizacion");
        bAgregarCot2.setBorderPainted(false);
        bAgregarCot2.setContentAreaFilled(false);
        bAgregarCot2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                bAgregarCot2MouseReleased(evt);
            }
        });

        bAgregarCot3.setForeground(new java.awt.Color(51, 51, 51));
        bAgregarCot3.setText("cotizacion");
        bAgregarCot3.setBorderPainted(false);
        bAgregarCot3.setContentAreaFilled(false);
        bAgregarCot3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                bAgregarCot3MouseReleased(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel3)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel1)
                                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addGroup(jPanel3Layout.createSequentialGroup()
                                            .addComponent(bModf)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(bAgregarCot))
                                        .addComponent(jLabel2)))
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel3Layout.createSequentialGroup()
                                    .addGap(9, 9, 9)
                                    .addComponent(jLabel4)))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(bAgregar, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(bAgregarCot1))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(bAnular, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(bAgregarCot3))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(bConsul)
                                .addGap(18, 18, 18)
                                .addComponent(bAgregarCot2))))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(56, 56, 56)
                        .addComponent(bReportes, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(44, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bAgregar)
                    .addComponent(bAgregarCot1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bModf)
                    .addComponent(bAgregarCot))
                .addGap(18, 18, 18)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bConsul)
                    .addComponent(bAgregarCot2))
                .addGap(31, 31, 31)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bAnular)
                    .addComponent(bAgregarCot3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 38, Short.MAX_VALUE)
                .addComponent(bReportes)
                .addGap(36, 36, 36))
        );

        jPanel4.setBackground(new java.awt.Color(51, 51, 51));

        bAceptar.setFont(new java.awt.Font("Eras Demi ITC", 0, 12)); // NOI18N
        bAceptar.setText("Agregar");
        bAceptar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                bAceptarMouseClicked(evt);
            }
        });

        labIDcotizacion.setFont(new java.awt.Font("Eras Demi ITC", 0, 12)); // NOI18N
        labIDcotizacion.setForeground(new java.awt.Color(255, 255, 255));
        labIDcotizacion.setText("ID cotización:");

        comboxCotizacion.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "No seleccionado" }));
        comboxCotizacion.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                comboxCotizacionItemStateChanged(evt);
            }
        });
        comboxCotizacion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboxCotizacionActionPerformed(evt);
            }
        });

        labNombrePro.setFont(new java.awt.Font("Eras Demi ITC", 0, 12)); // NOI18N
        labNombrePro.setForeground(new java.awt.Color(255, 255, 255));
        labNombrePro.setText("Nombre producto:");

        tNombrePro.setToolTipText("");
        tNombrePro.setPreferredSize(new java.awt.Dimension(164, 20));
        tNombrePro.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                tNombreProKeyTyped(evt);
            }
        });

        tVlrUnd.setToolTipText("");
        tVlrUnd.setPreferredSize(new java.awt.Dimension(164, 20));
        tVlrUnd.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                tVlrUndKeyTyped(evt);
            }
        });

        labVlrUnd.setFont(new java.awt.Font("Eras Demi ITC", 0, 12)); // NOI18N
        labVlrUnd.setForeground(new java.awt.Color(255, 255, 255));
        labVlrUnd.setText("Valor por unidad:");

        labCantidad.setFont(new java.awt.Font("Eras Demi ITC", 0, 12)); // NOI18N
        labCantidad.setForeground(new java.awt.Color(255, 255, 255));
        labCantidad.setText("Cantidad:");
        labCantidad.setToolTipText("");

        tCantidad.setToolTipText("");
        tCantidad.setPreferredSize(new java.awt.Dimension(164, 20));
        tCantidad.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                tCantidadKeyTyped(evt);
            }
        });

        tEmpresaCo.setToolTipText("");
        tEmpresaCo.setPreferredSize(new java.awt.Dimension(164, 20));
        tEmpresaCo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                tEmpresaCoKeyTyped(evt);
            }
        });

        labEmpresaCo.setFont(new java.awt.Font("Eras Demi ITC", 0, 12)); // NOI18N
        labEmpresaCo.setForeground(new java.awt.Color(255, 255, 255));
        labEmpresaCo.setText("Empresa en que se cotizó:");

        labNombreCliente.setFont(new java.awt.Font("Eras Demi ITC", 0, 12)); // NOI18N
        labNombreCliente.setForeground(new java.awt.Color(255, 255, 255));
        labNombreCliente.setText("Nombre cliente:");

        tNombreCliente.setPreferredSize(new java.awt.Dimension(164, 20));
        tNombreCliente.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                tNombreClienteKeyTyped(evt);
            }
        });

        tIDfactura.setToolTipText("");
        tIDfactura.setPreferredSize(new java.awt.Dimension(164, 20));
        tIDfactura.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                tIDfacturaKeyTyped(evt);
            }
        });

        labIDfactura.setFont(new java.awt.Font("Eras Demi ITC", 0, 12)); // NOI18N
        labIDfactura.setForeground(new java.awt.Color(255, 255, 255));
        labIDfactura.setText("ID factura:");

        labPrecio.setFont(new java.awt.Font("Eras Demi ITC", 0, 12)); // NOI18N
        labPrecio.setForeground(new java.awt.Color(255, 255, 255));
        labPrecio.setText("Precio:");

        tPrecio.setToolTipText("");
        tPrecio.setPreferredSize(new java.awt.Dimension(164, 20));
        tPrecio.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                tPrecioKeyTyped(evt);
            }
        });

        tCCcliente.setPreferredSize(new java.awt.Dimension(164, 20));
        tCCcliente.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                tCCclienteKeyTyped(evt);
            }
        });

        labCCcliente.setFont(new java.awt.Font("Eras Demi ITC", 0, 12)); // NOI18N
        labCCcliente.setForeground(new java.awt.Color(255, 255, 255));
        labCCcliente.setText("Cedula cliente:");

        labDir.setFont(new java.awt.Font("Eras Demi ITC", 0, 12)); // NOI18N
        labDir.setForeground(new java.awt.Color(255, 255, 255));
        labDir.setText("Dirección:");

        tDir.setToolTipText("");
        tDir.setPreferredSize(new java.awt.Dimension(164, 20));

        tTel.setToolTipText("");
        tTel.setPreferredSize(new java.awt.Dimension(164, 20));
        tTel.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                tTelKeyTyped(evt);
            }
        });

        labTel.setFont(new java.awt.Font("Eras Demi ITC", 0, 12)); // NOI18N
        labTel.setForeground(new java.awt.Color(255, 255, 255));
        labTel.setText("Telefono:");

        labDescrip.setFont(new java.awt.Font("Eras Demi ITC", 0, 12)); // NOI18N
        labDescrip.setForeground(new java.awt.Color(255, 255, 255));
        labDescrip.setText("Descripción producto:");

        tDescrip.setColumns(20);
        tDescrip.setRows(5);
        jScrollPane1.setViewportView(tDescrip);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(98, 98, 98)
                .addComponent(bAceptar)
                .addContainerGap(228, Short.MAX_VALUE))
            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel4Layout.createSequentialGroup()
                    .addGap(18, 18, 18)
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(labIDfactura)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(labNombrePro, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(labEmpresaCo)
                                        .addComponent(labPrecio)
                                        .addComponent(labCantidad)
                                        .addComponent(labTel)
                                        .addComponent(labIDcotizacion, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addComponent(labVlrUnd)
                                    .addComponent(labNombreCliente)
                                    .addComponent(labCCcliente)
                                    .addComponent(labDir))
                                .addGap(40, 40, 40)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(tNombrePro, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(tEmpresaCo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(tCantidad, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(comboxCotizacion, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(tVlrUnd, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(tNombreCliente, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addComponent(tCCcliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(tPrecio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(tDir, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(tTel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(tIDfactura, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addComponent(labDescrip)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addContainerGap(39, Short.MAX_VALUE)))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap(399, Short.MAX_VALUE)
                .addComponent(bAceptar)
                .addContainerGap())
            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel4Layout.createSequentialGroup()
                    .addGap(15, 15, 15)
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(labIDcotizacion)
                        .addComponent(comboxCotizacion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(labNombrePro)
                        .addComponent(tNombrePro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(labVlrUnd)
                        .addComponent(tVlrUnd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(labCantidad)
                        .addComponent(tCantidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(labEmpresaCo)
                        .addComponent(tEmpresaCo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(labNombreCliente)
                        .addComponent(tNombreCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(tIDfactura, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(labIDfactura))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(tPrecio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(labPrecio))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(labCCcliente)
                        .addComponent(tCCcliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(labDir, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(tDir, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(labTel, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(tTel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(labDescrip)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 4, Short.MAX_VALUE))
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(29, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cotizacionMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cotizacionMouseReleased
        if(this.cotizacion.isSelected()){
            this.venta.setSelected(false);
        }
    }//GEN-LAST:event_cotizacionMouseReleased

    private void ventaMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ventaMouseReleased
        if(this.venta.isSelected()){
            this.cotizacion.setSelected(false);
        }
    }//GEN-LAST:event_ventaMouseReleased

    private void tTelKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tTelKeyTyped
        char c = evt.getKeyChar();
        if(c<'0' || c>'9'){
            evt.consume();
        }
    }//GEN-LAST:event_tTelKeyTyped

    private void tCCclienteKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tCCclienteKeyTyped
        char c = evt.getKeyChar();
        if(c<'0' || c>'9'){
            evt.consume();
        }
    }//GEN-LAST:event_tCCclienteKeyTyped

    private void tPrecioKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tPrecioKeyTyped
        char c = evt.getKeyChar();
        if(c<'0' || c>'9'){
            evt.consume();
        }
    }//GEN-LAST:event_tPrecioKeyTyped

    private void tIDfacturaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tIDfacturaKeyTyped
        char c = evt.getKeyChar();
        if(c<'0' || c>'9'){
            evt.consume();
        }
    }//GEN-LAST:event_tIDfacturaKeyTyped

    private void tNombreClienteKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tNombreClienteKeyTyped
        char c = evt.getKeyChar();

        if(c != ' '){
            if(c<'A' || c>'Z'){
                if(c<'a' || c>'z'){
                    evt.consume();
                }
            }
        }
    }//GEN-LAST:event_tNombreClienteKeyTyped

    private void tEmpresaCoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tEmpresaCoKeyTyped
        char c = evt.getKeyChar();

        if(c != ' '){
            if(c<'A' || c>'Z'){
                if(c<'a' || c>'z'){
                    evt.consume();
                }
            }
        }
    }//GEN-LAST:event_tEmpresaCoKeyTyped

    private void tCantidadKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tCantidadKeyTyped
        char c = evt.getKeyChar();
        if(c<'0' || c>'9'){
            evt.consume();
        }
    }//GEN-LAST:event_tCantidadKeyTyped

    private void tVlrUndKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tVlrUndKeyTyped
        char c = evt.getKeyChar();
        if(c<'0' || c>'9'){
            evt.consume();
        }
    }//GEN-LAST:event_tVlrUndKeyTyped

    private void tNombreProKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tNombreProKeyTyped
        char c = evt.getKeyChar();

        if(c != ' '){
            if(c<'A' || c>'Z'){
                if(c<'a' || c>'z'){
                    evt.consume();
                }
            }
        }
    }//GEN-LAST:event_tNombreProKeyTyped

    private void comboxCotizacionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboxCotizacionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_comboxCotizacionActionPerformed

    private void comboxCotizacionItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_comboxCotizacionItemStateChanged
        if(this.labIDcotizacion.getText() == "ID facctura"){

            if(comboxCotizacion.getSelectedIndex() == 0){
                bAceptar.setEnabled(false);

                if(botonAceptar==2){ limpiarCampos(); habilitarCamposModfVenta(false);}
            }else{
                bAceptar.setEnabled(true);

                if(botonAceptar==2){ llenarCamposModfVenta(); habilitarCamposModfVenta(true);}
            }

        }

        if(this.labIDcotizacion.getText() == "ID cotizacion"){

            if(comboxCotizacion.getSelectedIndex() == 0){
                bAceptar.setEnabled(false);

                if(botonAceptar==2){ limpiarCampos(); habilitarCamposModfCotizacion(false);}
            }else{
                bAceptar.setEnabled(true);

                if(botonAceptar==2){ llenarCamposModfCotizacion(); habilitarCamposModfCotizacion(true);}
            }

        }
    }//GEN-LAST:event_comboxCotizacionItemStateChanged

    private void bAceptarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bAceptarMouseClicked

    }//GEN-LAST:event_bAceptarMouseClicked

    private void bAnularMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bAnularMouseReleased
        if(evt.isPopupTrigger()){
            vendedor.show(evt.getComponent(),evt.getX(),evt.getY());
        }

        if(evt.isPopupTrigger()){
            vendedor.show(evt.getComponent(),evt.getX(),evt.getY());
        }

        if(this.venta.isSelected()){
            cambiarVisibilidadCamposVentas(true);
            camposVentasConsulta(true);

            botonAceptar = 4;
            bAceptar.setText("Despedir");
            bAceptar.setVisible(true);
            bAceptar.setEnabled(false);

            comboxCotizacion.setSelectedIndex(0);
        }

        if(this.cotizacion.isSelected()){
            cambiarVisibilidadCamposVentas(true);
            camposVentasConsulta(true);

            botonAceptar = 4;
            bAceptar.setText("Despedir");
            bAceptar.setVisible(true);
            bAceptar.setEnabled(false);

            comboxCotizacion.setSelectedIndex(0);
        }
    }//GEN-LAST:event_bAnularMouseReleased

    private void bConsulMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bConsulMouseReleased
        if(evt.isPopupTrigger()){
            vendedor.show(evt.getComponent(),evt.getX(),evt.getY());
        }

        if(evt.isPopupTrigger()){
            vendedor.show(evt.getComponent(),evt.getX(),evt.getY());
        }

        if(this.venta.isSelected()){
            cambiarVisibilidadCamposVentas(true);
            camposVentasConsulta(true);

            botonAceptar = 3;
            bAceptar.setText("Consultar");
            bAceptar.setVisible(true);
            bAceptar.setEnabled(false);

            comboxCotizacion.setSelectedIndex(0);
        }

        if(this.cotizacion.isSelected()){
            cambiarVisibilidadCamposVentas(true);
            camposVentasConsulta(true);

            botonAceptar = 3;
            bAceptar.setText("Consultar");
            bAceptar.setVisible(true);
            bAceptar.setEnabled(false);

            comboxCotizacion.setSelectedIndex(0);
        }
    }//GEN-LAST:event_bConsulMouseReleased

    private void bModfMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bModfMouseReleased
        if(evt.isPopupTrigger()){
            vendedor.show(evt.getComponent(),evt.getX(),evt.getY());
        }

        if(evt.isPopupTrigger()){
            vendedor.show(evt.getComponent(),evt.getX(),evt.getY());
        }

        if(this.venta.isSelected()){
            cambiarVisibilidadCamposVentas(true);
            CambiarVisibilidadModCamposVenta(false);
            botonAceptar = 2;
            bAceptar.setText("Modificar");
            bAceptar.setVisible(true);
            bAceptar.setEnabled(false);

            comboxCotizacion.setSelectedIndex(0);
        }

        if(this.cotizacion.isSelected()){
            cambiarVisibilidadCamposVentas(true);
            CambiarVisibilidadModCamposVenta(true);

            botonAceptar = 2;
            bAceptar.setText("Modificar");
            bAceptar.setVisible(true);
            bAceptar.setEnabled(false);

            comboxCotizacion.setSelectedIndex(0);
        }
    }//GEN-LAST:event_bModfMouseReleased

    private void bAgregarMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bAgregarMouseReleased
        if(evt.isPopupTrigger()){
            vendedor.show(evt.getComponent(),evt.getX(),evt.getY());
        }

        if(evt.isPopupTrigger()){
            vendedor.show(evt.getComponent(),evt.getX(),evt.getY());
        }

        if(this.venta.isSelected()){
            cambiarVisibilidadCamposVentas(true);
            CambiarVisibilidadModCamposVenta(true);
            cambiarVisibilidadCamposCot(false);

            botonAceptar = 1;
            bAceptar.setText("Agregar");
            bAceptar.setVisible(true);
            bAceptar.setEnabled(true);
        }

        if(this.cotizacion.isSelected()){
            cambiarVisibilidadCamposVentas(true);
            CambiarVisibilidadModCamposVenta(false);
            cambiarVisibilidadCamposCot(true);

            botonAceptar = 1;
            bAceptar.setText("Agregar");
            bAceptar.setVisible(true);
            bAceptar.setEnabled(true);
        }
    }//GEN-LAST:event_bAgregarMouseReleased

    private void bReportesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bReportesActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_bReportesActionPerformed

    private void bConsulActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bConsulActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_bConsulActionPerformed

    private void bModfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bModfActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_bModfActionPerformed

    private void bAgregarCotMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bAgregarCotMouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_bAgregarCotMouseReleased

    private void bAgregarCot1MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bAgregarCot1MouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_bAgregarCot1MouseReleased

    private void bAgregarCot2MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bAgregarCot2MouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_bAgregarCot2MouseReleased

    private void bAgregarCot3MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bAgregarCot3MouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_bAgregarCot3MouseReleased

     public void cambiarVisibilidadCamposVentas(boolean varControl){
        labIDcotizacion.setVisible(false);
        comboxCotizacion.setVisible(false);

      //elementos para ventas  
      labIDfactura.setVisible(varControl);
      tIDfactura.setVisible(varControl);
      tIDfactura.setText("");
      labNombreCliente.setVisible(varControl);
      tNombreCliente.setVisible(varControl);
      tNombreCliente.setText("");
      labPrecio.setVisible(varControl);
      tPrecio.setVisible(varControl);
      tPrecio.setText("");
      labDescrip.setVisible(varControl);
      tDescrip.setVisible(varControl);
      tDescrip.setText("");
      jScrollPane1.setVisible(varControl);
      labCCcliente.setVisible(varControl);
      tCCcliente.setVisible(varControl);
      tCCcliente.setText("");
      labTel.setVisible(varControl);
      tTel.setVisible(varControl);
      tTel.setText("");
      
      //elementos para cotizacion
      labNombrePro.setVisible(varControl);
      tNombrePro.setVisible(varControl);
      tNombrePro.setText("");
      labVlrUnd.setVisible(varControl);
      tVlrUnd.setVisible(varControl);
      tVlrUnd.setText("");
      labCantidad.setVisible(varControl);
      tCantidad.setVisible(varControl);
      tCantidad.setText("");
      labDescrip.setVisible(varControl);
      tDescrip.setVisible(varControl);
      tDescrip.setText("");
      jScrollPane1.setVisible(varControl);
      labDir.setVisible(varControl);
      tDir.setVisible(varControl);
      tDir.setText("");
      labEmpresaCo.setVisible(varControl);
      tEmpresaCo.setVisible(varControl);
      tEmpresaCo.setText("");
      
    }
    
    //Quita los campos usados en la función consultar y despedir (ej:empleado)
    //varControl: true para indicar que sea visible, false para lo opuesto
    public void cambiarVisibilidadCamposCot(boolean varControl){           
          labIDcotizacion.setVisible(false);
        comboxCotizacion.setVisible(false);

      //elementos para ventas  
      labIDfactura.setVisible(!varControl);
      tIDfactura.setVisible(!varControl);
      tIDfactura.setText("");
      labNombreCliente.setVisible(!varControl);
      tNombreCliente.setVisible(!varControl);
      tNombreCliente.setText("");
      labPrecio.setVisible(!varControl);
      tPrecio.setVisible(!varControl);
      tPrecio.setText("");
      labDescrip.setVisible(!varControl);
      tDescrip.setVisible(!varControl);
      tDescrip.setText("");
      jScrollPane1.setVisible(!varControl);
      labCCcliente.setVisible(!varControl);
      tCCcliente.setVisible(!varControl);
      tCCcliente.setText("");
      labTel.setVisible(!varControl);
      tTel.setVisible(!varControl);
      tTel.setText("");
      
      //elementos para cotizacion
      labNombrePro.setVisible(varControl);
      tNombrePro.setVisible(varControl);
      tNombrePro.setText("");
      labVlrUnd.setVisible(varControl);
      tVlrUnd.setVisible(varControl);
      tVlrUnd.setText("");
      labCantidad.setVisible(varControl);
      tCantidad.setVisible(varControl);
      tCantidad.setText("");
      labDescrip.setVisible(varControl);
      tDescrip.setVisible(varControl);
      tDescrip.setText("");
      jScrollPane1.setVisible(varControl);
      labDir.setVisible(varControl);
      tDir.setVisible(varControl);
      tDir.setText("");
      labEmpresaCo.setVisible(varControl);
      tEmpresaCo.setVisible(varControl);
      tEmpresaCo.setText("");
    }
    
    public void CambiarVisibilidadModCamposVenta(boolean varControl){
       
        if(varControl == false){
        labIDcotizacion.setText("ID factura:");
        labIDcotizacion.setVisible(!varControl);
        comboxCotizacion.setVisible(!varControl);
        }
        else{
        labIDcotizacion.setText("ID cotizacion:");
        labIDcotizacion.setVisible(varControl);
        comboxCotizacion.setVisible(varControl);
        }
              
      //elementos para ventas  
      labIDfactura.setVisible(!varControl);
      tIDfactura.setVisible(!varControl);
      tIDfactura.setText("");
      tIDfactura.setEnabled(varControl);
      labNombreCliente.setVisible(!varControl);
      tNombreCliente.setVisible(!varControl);
      tNombreCliente.setText("");
      tNombreCliente.setEnabled(varControl);
      labPrecio.setVisible(!varControl);
      tPrecio.setVisible(!varControl);
      tPrecio.setText("");
      tPrecio.setEnabled(varControl);
      labDescrip.setVisible(!varControl);
      tDescrip.setVisible(!varControl);
      tDescrip.setText("");
      tDescrip.setEnabled(varControl);
      jScrollPane1.setVisible(!varControl);
      labCCcliente.setVisible(!varControl);
      tCCcliente.setVisible(!varControl);
      tCCcliente.setText("");
      tCCcliente.setEnabled(varControl);
      labTel.setVisible(!varControl);
      tTel.setVisible(!varControl);
      tTel.setText("");
      tTel.setEnabled(varControl);
      
      //elementos para cotizacion
      labNombrePro.setVisible(varControl);
      tNombrePro.setVisible(varControl);
      tNombrePro.setText("");
      tNombrePro.setEnabled(!varControl);
      labVlrUnd.setVisible(varControl);
      tVlrUnd.setVisible(varControl);
      tVlrUnd.setText("");
      tVlrUnd.setEnabled(!varControl);
      labCantidad.setVisible(varControl);
      tCantidad.setVisible(varControl);
      tCantidad.setText("");
      tCantidad.setEnabled(!varControl);
      labDescrip.setVisible(varControl);
      tDescrip.setVisible(varControl);
      tDescrip.setText("");
      tDescrip.setEnabled(!varControl);
      jScrollPane1.setVisible(varControl);
      labDir.setVisible(varControl);
      tDir.setVisible(varControl);
      tDir.setText("");
      tDir.setEnabled(!varControl);
      labEmpresaCo.setVisible(varControl);
      tEmpresaCo.setVisible(varControl);
      tEmpresaCo.setText("");
      tEmpresaCo.setEnabled(!varControl);
    }
    
    public void camposVentasConsulta(boolean varControl){
    
        if(this.cotizacion.isSelected()){
        labIDcotizacion.setText("ID cotizacion:");
        }
        else{
        labIDcotizacion.setText("ID factura:");
        }
        
        
        labIDcotizacion.setVisible(varControl);
        comboxCotizacion.setVisible(varControl);

      //elementos para ventas  
      labIDfactura.setVisible(!varControl);
      tIDfactura.setVisible(!varControl);
      labNombreCliente.setVisible(!varControl);
      tNombreCliente.setVisible(!varControl);
      labPrecio.setVisible(!varControl);
      tPrecio.setVisible(!varControl);
      labDescrip.setVisible(!varControl);
      tDescrip.setVisible(!varControl);
      jScrollPane1.setVisible(!varControl);
      labCCcliente.setVisible(!varControl);
      tCCcliente.setVisible(!varControl);
      labTel.setVisible(!varControl);
      tTel.setVisible(!varControl);
      
      //elementos para cotizacion
      labNombrePro.setVisible(!varControl);
      tNombrePro.setVisible(!varControl);
      labVlrUnd.setVisible(!varControl);
      tVlrUnd.setVisible(!varControl);
      labCantidad.setVisible(!varControl);
      tCantidad.setVisible(!varControl);
      labDescrip.setVisible(!varControl);
      tDescrip.setVisible(!varControl);
      jScrollPane1.setVisible(!varControl);
      labDir.setVisible(!varControl);
      tDir.setVisible(!varControl);
      labEmpresaCo.setVisible(!varControl);
      tEmpresaCo.setVisible(!varControl);
    }
    
    private void limpiarCampos(){
       tEmpresaCo.setText("");
       tDir.setText("");
       tDescrip.setText("");
       tCantidad.setText("");
       tVlrUnd.setText("");
       tNombrePro.setText("");
       tTel.setText("");
       tCCcliente.setText("");
       tPrecio.setText("");
       tNombreCliente.setText("");
       tIDfactura.setText("");
    } 
    
    private void llenarCamposModfVenta(){
    
       String id = listaIds[comboxCotizacion.getSelectedIndex()-1];
       Venta vent = bD.leerVentaPorId(id);
       
       tDescrip.setText(vent.getDescripcionVenta());
       tTel.setText(vent.getTelefonoCliente());
       tCCcliente.setText(vent.getCedulaCliente());
       tPrecio.setText(Float.toString(vent.getValorVenta()));
       tNombreCliente.setText(vent.getNombreCliente());
       tIDfactura.setText(vent.getId());
    }
    
    
    private void llenarCamposModfCotizacion(){
       String id = listaIds[comboxCotizacion.getSelectedIndex()-1];
       Cotizacion cot = bD.leerCotizacionPorId(id);
        
       tEmpresaCo.setText(cot.getNombreEmpresa());
       tDir.setText(cot.getDireccionEmpresa());
       tCantidad.setText(Float.toString(cot.getCantidad()));
       tVlrUnd.setText(Float.toString(cot.getValorUnitario()));
       tNombrePro.setText(cot.getNombreProducto());
    }
    
    public void habilitarCamposModfVenta(boolean varControl){
    
       tDescrip.setEnabled(varControl);
       tTel.setEnabled(varControl);
       tCCcliente.setEnabled(varControl);
       tPrecio.setEnabled(varControl);
       tNombreCliente.setEnabled(varControl);
       tIDfactura.setEnabled(varControl);
    
    }
    
    public void habilitarCamposModfCotizacion(boolean varControl){
    
       tEmpresaCo.setEnabled(varControl);
       tDir.setEnabled(varControl);
       tCantidad.setEnabled(varControl);
       tVlrUnd.setEnabled(varControl);
       tNombrePro.setEnabled(varControl);
       
    }
    
    public static void main(String args[]) {            
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new prinVendedor().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bAceptar;
    private javax.swing.JButton bAgregar;
    private javax.swing.JButton bAgregarCot;
    private javax.swing.JButton bAgregarCot1;
    private javax.swing.JButton bAgregarCot2;
    private javax.swing.JButton bAgregarCot3;
    private javax.swing.JButton bAnular;
    private javax.swing.JButton bConsul;
    private javax.swing.JButton bModf;
    private javax.swing.JToggleButton bReportes;
    private javax.swing.JComboBox<String> comboxCotizacion;
    private javax.swing.JCheckBoxMenuItem cotizacion;
    private javax.swing.JLabel fecha;
    private javax.swing.JLabel fechaYhora;
    private javax.swing.JLabel hora;
    private javax.swing.JLabel iconUsu;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel labCCcliente;
    private javax.swing.JLabel labCantidad;
    private javax.swing.JLabel labDescrip;
    private javax.swing.JLabel labDir;
    private javax.swing.JLabel labEmpresaCo;
    private javax.swing.JLabel labIDcotizacion;
    private javax.swing.JLabel labIDfactura;
    private javax.swing.JLabel labLogo;
    private javax.swing.JLabel labNombreCliente;
    private javax.swing.JLabel labNombrePro;
    private javax.swing.JLabel labPrecio;
    private javax.swing.JLabel labTel;
    private javax.swing.JLabel labVlrUnd;
    private javax.swing.JTextField tCCcliente;
    private javax.swing.JTextField tCantidad;
    private javax.swing.JTextArea tDescrip;
    private javax.swing.JTextField tDir;
    private javax.swing.JTextField tEmpresaCo;
    private javax.swing.JTextField tIDfactura;
    private javax.swing.JTextField tNombreCliente;
    private javax.swing.JTextField tNombrePro;
    private javax.swing.JTextField tPrecio;
    private javax.swing.JTextField tTel;
    private javax.swing.JTextField tVlrUnd;
    private javax.swing.JPopupMenu vendedor;
    private javax.swing.JCheckBoxMenuItem venta;
    // End of variables declaration//GEN-END:variables
}
